/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.RequestDispatcher;


/**
 *
 * @author HARI CHANDANA
 */
public class welcome2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>QUIZ</title>"); 
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">");
            out.println("<link href=\"registration.html\">");
            out.println("</head>");
            out.println("<body>");
            //out.println("<h1>Servlet welcome2 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
           
            
            String u = request.getParameter("NUname");
            String pswd = request.getParameter("NPass");

            try{
                Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinequiz","root","CHan@5053");
                PreparedStatement ps = conn.prepareStatement("select * from user_login where username=?");
                ps.setString(1, u);
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    out.println("<h2>Sorry the user "+u+" already exists</h2>");
                    RequestDispatcher rd = request.getRequestDispatcher("registration.html");
                    rd.include(request, response);
                }
                
                else{
                    
                    PreparedStatement ps1 = conn.prepareStatement("insert into user_login values(?,?)");
                    ps1.setString(1, u);
                    ps1.setString(2, pswd);
                    ps1.executeUpdate();
                    
                    RequestDispatcher rd = request.getRequestDispatcher("login.html");
                    rd.forward(request, response);
                }
                
              
                conn.close();
            }
            
            catch(ClassNotFoundException | SQLException se){
                se.printStackTrace();
            }
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
