/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;
import java.sql.*;
import java.text.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author HARI CHANDANA
 */
public class score extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>QUIZ</title>");  
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">");
            out.println("<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2 style=\"text-align:center\">You've submitted the exam </h2>");
            out.println("</body>");
            out.println("</html>");
            
            out.println("<form action=\"results\" method=\"post\">"
                    + "<input type=\"submit\" name=\"tr\" id=\"tr\" value=\"Test Results\"></form>");
            out.println("<form action=\"logout\" method=\"post\">"
                    + "<input type=\"submit\" name=\"lo\" id=\"lo\" value=\"Logout\"></form>");
            
            
    
            int total = 0;
            int i = 0;
            ArrayList<String> answ = new ArrayList<String>();
            answ.add(request.getParameter("q1"));
            answ.add(request.getParameter("q2"));
            answ.add(request.getParameter("q3"));
            answ.add(request.getParameter("q4"));
            answ.add(request.getParameter("q5"));
            answ.add(request.getParameter("q6"));
            answ.add(request.getParameter("q7"));
            answ.add(request.getParameter("q8"));
            answ.add(request.getParameter("q9"));
            answ.add(request.getParameter("q10"));
            
     
            HttpSession session=request.getSession(false);
            String n = (String)session.getAttribute("Uname");
            String subj = (String)session.getAttribute("subject_name");
            
            
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinequiz","root","CHan@5053");
                PreparedStatement ps = conn.prepareStatement("select * from ques_answ where subject_name=?");
                ps.setString(1, subj);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    if((rs.getString("answer")).equals(answ.get(i))){
                        total = total + 1;
                    }
                    i = i + 1;
                }
                
                long millis=System.currentTimeMillis();  
                java.sql.Date date=new java.sql.Date(millis);
                
               
                
                PreparedStatement ps1 = conn.prepareStatement("insert into student_scores values(?,?,?,?,?)");
                ps1.setString(1, n);
                ps1.setString(2, subj);
                ps1.setInt(3, total);
                ps1.setInt(4, i);
                ps1.setDate(5, date);
                ps1.executeUpdate();
                
                 conn.close();
                 
                 float sc = (total/i)*100;
              
                
                out.println("<div class=\"w3-container w3-center w3-animate-top\">");
                out.println("<h2 style=\"text-align:center\">Your Score out of "+i+": "+total+"</h2><br>");
                
                if(sc==0 && sc<50){
                    out.println("<h2 style=\"text-align:center\">You've haven't scored the pass marks..Better luck next time</h2></div>");
                }
                else if(sc>=50 && sc<=86){
                    out.println("<h2 style=\"text-align:center\">Good Score!!</h2></div>");
                }
                else{
                    out.println("<h2 style=\"text-align:center\">Excellent Score!! keep it up..</h2></div>");
                }
                
               
                
            }
            
            catch(ClassNotFoundException | SQLException s){
                
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(score.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(score.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
