/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;
import java.sql.*;

/**
 *
 * @author HARI CHANDANA
 */
public class subj_phy extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>QUIZ</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">");
            out.println("<h2 style=\"text-align:center\">Test</h2>");
            out.println("<style>\n" +
"        <style>\n" +
"        * {\n" +
"  box-sizing: border-box;\n" +
"} \n" +
"\n" +
" #clockdiv{ \n" +
"    font-family: sans-serif; \n" +
"    position: absolute; \n" +
"    top: 20px; \n" +
"    right: 0px; \n" +
"    color: #fff; \n" +
"    display: inline-block; \n" +
"    font-weight: 10; \n" +
"    text-align: center; \n" +
"    font-size: 15px;\n" +
"\n" +
"\n" +
"} \n" +
"#clockdiv > div{ \n" +
"    padding: 10px; \n" +
"    border-radius: 3px; \n" +
"    background: #00BF96; \n" +
"    display: inline-block;\n" +
"    \n" +
"\n" +
"} \n" +
"#clockdiv div > span{ \n" +
"    padding: 15px; \n" +
"    border-radius: 3px; \n" +
"    background: #00816A; \n" +
"    display: inline-block; \n" +
"} \n" +
"#smalltext{ \n" +
"    padding-top: 5px; \n" +
"    font-size: 8px; \n" +
"} \n" +
"</style> \n" +
"\n" +
"    </style>");
            
            out.println("<div class=\"collapse navbar-collapse\" id=\"myNavbar\">\n" +
"        <ul class=\"nav navbar-nav navbar-right\">\n" +
"\n" +
"          <div id=\"clockdiv\"> \n" +
"  <div> \n" +
"    <span class=\"hours\" id=\"hour\"></span> \n" +
"    <div class=\"smalltext\">Hours</div> \n" +
"  </div> \n" +
"  <div> \n" +
"    <span class=\"minutes\" id=\"minute\"></span> \n" +
"    <div class=\"smalltext\">Minutes</div> \n" +
"  </div> \n" +
"  <div> \n" +
"    <span class=\"seconds\" id=\"second\"></span> \n" +
"    <div class=\"smalltext\">Seconds</div> \n" +
"  </div> \n" +
"</div> \n" +
"  \n" +
"<p id=\"demo\"></p> \n" +
"\n" +
"<script>\n" +
"function myFunction() {\n" +
"  var d = new Date();\n" +
"  return d.setMinutes(d.getMinutes() + 5);\n" +
"}\n" +
"</script>\n" +
"  \n" +
"<script> \n" +
"\n" +
"var deadline = myFunction();\n" +
"var x = setInterval(function() { \n" +
" \n" +
"var now = new Date().getTime(); \n" +
"var t = deadline - now; \n" +
"var days = Math.floor(t/ (1000 * 60 * 60 * 24)); \n" +
"var hours = Math.floor((t%(1000 * 60 * 60 * 24))/(1000 * 60 * 60)); \n" +
"var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60)); \n" +
"var seconds = Math.floor((t % (1000 * 60)) / 1000); \n" +
"document.getElementById(\"hour\").innerHTML =hours; \n" +
"document.getElementById(\"minute\").innerHTML = minutes;  \n" +
"document.getElementById(\"second\").innerHTML =seconds;  \n" +
"if (t < 0) {\n" +
"            window.location.replace(\"score\");\n" +
"            }\n" +
"}, 1000); \n" +
"</script> \n" +
"\n" +
"        </ul>\n" +
"      </div>\n" +
"    </div>\n" +
"  </nav>\n" +
"</div>");
            
            out.println("</body>");
            out.println("</html>");
           out.println("<form action=\"logout\" method=\"post\">"
                    + "<input type=\"submit\" name=\"lo\" id=\"lo\" value=\"Logout\"></form>");
            
            
            ArrayList<String> ques = new ArrayList<String>();
            ArrayList<String> options = new ArrayList<String>();
            ArrayList<String> counter = new ArrayList<String>();
            String sb = request.getParameter("butt");
            
            HttpSession session=request.getSession();  
            session.setAttribute("subject_name",sb);
            
            
            int i = 0;
           
            int k = 1;
           
        
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinequiz","root","CHan@5053");
                PreparedStatement ps = conn.prepareStatement("select * from ques_answ where subject_name=?");
                ps.setString(1, sb);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    ques.add(rs.getString("question"));
                    options.add(rs.getString("option1"));
                    options.add(rs.getString("option2"));
                    options.add(rs.getString("option3"));
                    options.add(rs.getString("option4"));
                    counter.add("q"+k);
                    k =k+1;
                }
            
                conn.close();
           
            }
            
        
            catch(ClassNotFoundException | SQLException s){
            
            }
            
        
            finally{
                 int j = 0;
                  int c = 1;
                out.println("<div class=\"welc\"><form action=\"score\" method=\"post\">");
                for(i=0;i<ques.size();i++){
                        out.println("<label>"+c+". "+ ques.get(i)+"</label><br>");
                        out.println("<input type=\"radio\" name="+counter.get(i)+" id="+options.get(j)+" value="+options.get(j)+">");
                        out.println("<label for="+options.get(j)+">"+options.get(j)+"</label><br>");
                        j = j+1;
                        out.println("<input type=\"radio\" name="+counter.get(i)+" id="+options.get(j)+" value="+options.get(j)+">");
                        out.println("<label for="+options.get(j)+">"+options.get(j)+"</label><br>");
                        j = j+1;
                        out.println("<input type=\"radio\" name="+counter.get(i)+" id="+options.get(j)+" value="+options.get(j)+">");
                        out.println("<label for="+options.get(j)+">"+options.get(j)+"</label><br>");
                        j = j+1;
                        out.println("<input type=\"radio\" name="+counter.get(i)+" id="+options.get(j)+" value="+options.get(j)+">");
                        out.println("<label for="+options.get(j)+">"+options.get(j)+"</label><br><br>");
                        j = j+1;
                        c = c+1;
                }
                out.println("<br>");
               out.println("<input type=\"submit\" style=\"height:40px;width:80px\" name=\"sb\" value=\"Submit\"></form></div>");
            }
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
