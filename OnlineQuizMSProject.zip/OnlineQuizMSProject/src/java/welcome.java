/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;
/**
 *
 * @author HARI CHANDANA
 */
public class welcome extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>QUIZ</title>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2 style=\"text-align:right\">Welcome " + request.getParameter("Uname") + "</h2>");
            out.println("</body>");
            out.println("</html>");
            HttpSession session=request.getSession();  
            session.setAttribute("Uname",request.getParameter("Uname"));
            
            
            out.println("<form action=\"results\" method=\"post\">"
                    + "<input type=\"submit\" name=\"tr\" id=\"tr\" value=\"Test Results\"></form>");
            out.println("<form action=\"logout\" method=\"post\">"
                    + "<input type=\"submit\" name=\"lo\" id=\"lo\" value=\"Logout\"></form>");
            
            
            ArrayList<String> sbj = new ArrayList<String>();
            
            try{
                Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinequiz","root","CHan@5053");
                PreparedStatement ps = conn.prepareStatement("select distinct(subject_name) from ques_answ");
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    sbj.add(rs.getString(1));
                }
                
                conn.close();
            }
            
            catch(ClassNotFoundException | SQLException s){
                
            }
            
            
           finally{ 
           out.println("<div class=\"tetrs\"><label><b>INSTRUCTIONS</b></label><br><br>"
                   + "<ul>\n" +
"                        <li><p style=\"color:lawngreen\">This is a online based test.</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">Select a subject from below list.</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">After selecting,click on take test button.</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">You will be re-directing to a new webpage.</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">The timer starts automatically.</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">Each subject will have 10 questions</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">If you complete your test,click on submit button</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">The test stops automatically after the time</p></li>\n" +
"                        <li><p style=\"color:lawngreen\">After your completion of the test,the results are displayed </p></li>\n" +
"                    </ul><br><br><br><br>"
                   +"<label><b>SELECT A SUBJECT:</b></label><br><br>");
                   for(int i=0;i<sbj.size();i++){
                       out.println("<form method=\"post\" action=\"subj_phy\">");
                       out.println("<input type=\"submit\" style=\"height:40px;width:80px\" name=\"butt\" value="+sbj.get(i)+"></form><br><br>");
                   }
            }
      
  }
        
    

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
